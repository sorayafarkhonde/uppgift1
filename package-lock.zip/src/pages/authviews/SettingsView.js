import React from 'react'

export const SettingsView = () => {
    return (
        <div>
            <h1>ffggfgfgfg</h1>

            </div>
    )
}
