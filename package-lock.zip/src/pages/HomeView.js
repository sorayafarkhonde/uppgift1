import React from 'react'

//import {useEffect, useState} from 'react'

export const HomeView = () => {
  /*  const[number,setNumber]=useState(0)
    useEffect(()=>{
        alert('HomeView')
        //return(()=>{alert('leaving')})
    },[])
            <h1>{number}</h1>
            <button onClick = {() => setNumber(number+1)}>Increament</button>
       */
    return (
        <div>
            <h1>This is the homeview</h1>
 </div>
    )
}
