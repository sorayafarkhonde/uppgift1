import React from 'react'

export const NewsView = () => {
    return (
        <div>
            NEWS
        </div>
    )
}
