import React from 'react'

export const BrandsView = () => {
    return (
        <div>
            BRANDS
        </div>
    )
}
